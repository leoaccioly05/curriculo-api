package com.seuapp.first_spring_app.model;

import com.seuapp.first_spring_app.enums.NivelFormacao;

import javax.persistence.*;

@Entity
@Table(name = "formacoes_academicas")
public class FormacaoAcademica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String instituicao;

    @Column(nullable = false)
    private String curso;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private NivelFormacao nivel;

    @ManyToOne
    @JoinColumn(name = "curriculum_id", nullable = false)
    private Curriculum curriculum;

    // Getters e Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public NivelFormacao getNivel() {
        return nivel;
    }

    public void setNivel(NivelFormacao nivel) {
        this.nivel = nivel;
    }

    public Curriculum getCurriculum() {
        return curriculum;
    }

    public void setCurriculum(Curriculum curriculum) {
        this.curriculum = curriculum;
    }
}