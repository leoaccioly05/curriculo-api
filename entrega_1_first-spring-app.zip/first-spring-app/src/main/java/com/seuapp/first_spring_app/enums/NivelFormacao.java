package com.seuapp.first_spring_app.enums;

public enum NivelFormacao {
    FUNDAMENTAL,
    MEDIO,
    TECNICO,
    GRADUACAO,
    POS_GRADUACAO,
    MESTRADO,
    DOUTORADO
}