package com.seuapp.first_spring_app.mapper;

import com.seuapp.first_spring_app.dto.FormacaoAcademicaDTO;
import com.seuapp.first_spring_app.model.Curriculum;
import com.seuapp.first_spring_app.model.FormacaoAcademica;
import com.seuapp.first_spring_app.repository.CurriculumRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FormacaoAcademicaMapper {

    @Autowired
    private CurriculumRepository curriculumRepository;

    public FormacaoAcademica toEntity(FormacaoAcademicaDTO dto) {
        Curriculum curriculum = curriculumRepository.findById(dto.getCurriculumId())
                .orElseThrow(() -> new IllegalArgumentException("Currículo não encontrado com ID: " + dto.getCurriculumId()));

        FormacaoAcademica entity = new FormacaoAcademica();
        entity.setId(dto.getId());
        entity.setCurso(dto.getCurso());
        entity.setInstituicao(dto.getInstituicao());
        entity.setNivel(dto.getNivel());
        entity.setCurriculum(curriculum);
        return entity;
    }

    public FormacaoAcademicaDTO toDTO(FormacaoAcademica entity) {
        FormacaoAcademicaDTO dto = new FormacaoAcademicaDTO();
        dto.setId(entity.getId());
        dto.setCurso(entity.getCurso());
        dto.setInstituicao(entity.getInstituicao());
        dto.setNivel(entity.getNivel());
        dto.setCurriculumId(entity.getCurriculum().getId());
        return dto;
    }
}